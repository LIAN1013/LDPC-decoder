#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"

// initial LLR=2yi/(sigma^2) data
void initial(double* channel_sigma, double* channel_output, double* LLR_ChannelCurrent, double* LLR_FinalResult)
{
    for (int i = 0; i < N; i++)
    {
        LLR_ChannelCurrent[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_FinalResult[i] = LLR_ChannelCurrent[i];
    }
}

// --- log domain decoder main function ---
bool Decode_SumProduct(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output) 
{
    Read_H_MatrixByAlist();

    double* LLR_Channel = (double*)calloc(N , sizeof(double));
    double* LLR_Current = (double*)calloc(N , sizeof(double));
    double* phibeta = (double*)calloc(N , sizeof(double));
    int* Ci = (int*)calloc(N , sizeof(int));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
        //printf("%lf %lf\n", LLR_Channel[i], LLR_Current[i]);

        //NOT SURE
        phibeta[i] = 0;
    }
    //printf("\n");

    *decoder_iteration = 0;

    long long truebit = 0, falsebit = 0;

    while (*decoder_iteration < decoder_max_iteration) 
    {
        truebit = 0, falsebit = 0;
        
        for (int j = 0; j < N; j++) phibeta[j] = SPA_phi(fabs(LLR_Current[j]));
        //for (int j = 0; j < N; j++) printf("Precaculate: LLR_CURRENT= %lf   phibeta[%d]=%lf  fabs=%lf out=%lf\n", LLR_Current[j], j, phibeta[j],fabs(LLR_Current[j]), SPA_phi(fabs(LLR_Current[j])));

        // Check Node Update (�ϥΤ@���}�C�s��)
        for (int i = 0; i < M; i++) {
            int TotalNegativeCount = 0;
            double TotalPhi = 0;
            int offset = H_rows[i].offset;

            for (int j = 0; j < H_rows[i].row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j]; // �令�@������
                if (LLR_Current[col_idx] < 0) TotalNegativeCount++;
                TotalPhi += phibeta[col_idx];
                //printf("TOTALPHI=%lf phibeta[%d]%lf\n", TotalPhi,col_idx, phibeta[col_idx]);
            }
            //printf("TOTALPHI=%lf\n", TotalPhi);
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];
                int sign = ((LLR_Current[col_idx] < 0 ? TotalNegativeCount - 1 : TotalNegativeCount) % 2 == 0) ? 1 : -1;
                double except_phi = TotalPhi - phibeta[col_idx];
                ReturnTotalExceptI[col_idx] += sign * SPA_phi(except_phi);
            }
        }

        bool isAllZero = true;
        for (int i = 0; i < N; i++) {
            double LLR_FinalResult = LLR_Channel[i] + ReturnTotalExceptI[i];
            Ci[i] = (LLR_FinalResult > 0) ? 0 : 1;
            if (Ci[i] == 0) truebit++; else falsebit++;
            LLR_Current[i] = LLR_FinalResult;
            //printf("AFETR:  %lf %lf\n", LLR_Channel[i], LLR_Current[i]);
        }
        //printf("\n");

        // ���� (�ϥΤ@���}�C�s��)
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) isAllZero = false;
        }

        if (isAllZero == true) {
            SPA->truebits += truebit; 
            SPA->falsebits += falsebit;

            free(LLR_Channel); free(LLR_Current); free(phibeta); free(Ci), free(ReturnTotalExceptI);
            FREE_H_MatrixByAlist();
            return true;
        }
        *decoder_iteration += 1;
    }
    SPA->truebits += truebit; 
    SPA->falsebits += falsebit;

    free(LLR_Channel); free(LLR_Current); free(phibeta); free(Ci), free(ReturnTotalExceptI);
    FREE_H_MatrixByAlist();
    return false;
}

// �w�q Box-Plus �B�� (Min-Sum + Correction Factor)
double box_plus(double L1, double L2) {
    double sign1 = (L1 < 0) ? -1.0 : 1.0;
    double sign2 = (L2 < 0) ? -1.0 : 1.0;
    double abs1 = fabs(L1);
    double abs2 = fabs(L2);
    double min_val = (abs1 < abs2) ? abs1 : abs2;

    // --- ��k A�G��T�ץ��� s(x, y) 
    double sum_abs = fabs(L1 + L2);
    double diff_abs = fabs(L1 - L2);
    double correction = log(1.0 + exp(-sum_abs)) - log(1.0 + exp(-diff_abs));

    /* // --- ��k B�G����ץ��� s~(x, y) (�t�׸���) ---
    double correction = 0.0;
    double c = 0.5; // �`�� c �q�`�]�� 0.5 ���k
    if (sum_abs < 2.0 && diff_abs > 2.0 * sum_abs) {
        correction = c;
    }else if (diff_abs < 2.0 && sum_abs > 2.0 * diff_abs) {
        correction = -c;
    }
    */

    return sign1 * sign2 * min_val + correction;
}

// --- minsum-c decoder main function ---
bool Decode_MinSumC(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output) 
{
    Read_H_MatrixByAlist();

    double* LLR_Channel = (double*)calloc(N, sizeof(double));
    double* LLR_Current = (double*)calloc(N, sizeof(double));
    int* Ci = (int*)calloc(N, sizeof(int));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    // �ǳ� Forward-Backward �}�C�A�Ω� Check Node �������j�p�� Box-Plus
    // �j�p�t�m�� N �O�̦w�����W�� (�T�O���|�W�L�̤j�� row_weight)
    double* forward = (double*)calloc(N, sizeof(double));
    double* backward = (double*)calloc(N, sizeof(double));

    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
    }

    *decoder_iteration = 0;

    long long truebit = 0, falsebit = 0;
    while (*decoder_iteration < decoder_max_iteration) 
    {
        truebit = 0, falsebit = 0;

        // �C�����N�k�s Check Node ���~�b�T���ֿn
        memset(ReturnTotalExceptI, 0, N * sizeof(double));

        // --- Check Node Update (�ϥ� Forward-Backward �p�� Box-Plus) ---
        for (int i = 0; i < M; i++) {
            int offset = H_rows[i].offset;
            int row_weight = H_rows[i].row_weight;

            if (row_weight == 0) continue; // ���b�B�z

            // 1. �p�� Forward �}�C (�q���[��k)
            forward[0] = LLR_Current[H_row_places_flat[offset]];
            for (int j = 1; j < row_weight; j++) {
                double L_next = LLR_Current[H_row_places_flat[offset + j]];
                forward[j] = box_plus(forward[j - 1], L_next);
            }

            // 2. �p�� Backward �}�C (�q�k�[�쥪)
            backward[row_weight - 1] = LLR_Current[H_row_places_flat[offset + row_weight - 1]];
            for (int j = row_weight - 2; j >= 0; j--) {
                double L_prev = LLR_Current[H_row_places_flat[offset + j]];
                backward[j] = box_plus(backward[j + 1], L_prev);
            }

            // 3. �զX�X Exclude-I (�ư��ۨ�) ���T���ðe�^ Variable Node
            for (int j = 0; j < row_weight; j++) {
                double msg_out;
                if (j == 0) {
                    msg_out = backward[1]; // �Ĥ@�Ӹ`�I�A�u�ݫ�V�}�C
                }
                else if (j == row_weight - 1) {
                    msg_out = forward[row_weight - 2]; // �̫�@�Ӹ`�I�A�u�ݫe�V�}�C
                }
                else {
                    msg_out = box_plus(forward[j - 1], backward[j + 1]); // �����`�I�A�e�V + ��V
                }

                int col_idx = H_row_places_flat[offset + j];
                ReturnTotalExceptI[col_idx] += msg_out;
            }
        }

        bool isAllZero = true;

        // --- Variable Node Update & Hard Decision ---
        for (int i = 0; i < N; i++) {
            double LLR_FinalResult = LLR_Channel[i] + ReturnTotalExceptI[i];
            Ci[i] = (LLR_FinalResult > 0) ? 0 : 1;

            if (Ci[i] == 0) {
                truebit++;
            }
            else {
                falsebit++;
            }

            LLR_Current[i] = LLR_FinalResult;
        }

        // --- Syndrome Check ---
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break;
            }
        }

        if (isAllZero == true) {
            MinsumC->truebits += truebit;
            MinsumC->falsebits += falsebit;

            free(LLR_Channel);
            free(LLR_Current);
            free(Ci);
            free(ReturnTotalExceptI);
            free(forward);
            free(backward);
            FREE_H_MatrixByAlist();

            return true;
        }
        *decoder_iteration += 1;
    }
    // �p�G�{���]��o�̡A�N����Ҧ����N���Ƴ��Υ��F�٬O�S�ѥX�� (�ѽX����)
    // ����̫�@�����N�����~���p
    MinsumC->truebits += truebit;
    MinsumC->falsebits += falsebit;

    free(LLR_Channel);
    free(LLR_Current);
    free(Ci);
    free(ReturnTotalExceptI);
    free(forward);
    free(backward);
    FREE_H_MatrixByAlist();

    return false;

}

