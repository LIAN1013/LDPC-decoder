﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"

/*
    Update Record
    2026/05/17 18:07 Add Path Prefix
    2026/05/17 19:36

*/

void init(void)
{
    SPA = (BER*)calloc(1,sizeof(BER));
    MinsumC = (BER*)calloc(1,sizeof(BER));
    Minsum = (BER*)calloc(1,sizeof(BER));
}

void Create_SNR_Plot(void)
{
    FILE* Plot = fopen(PLOT_FILE, "w");
    if (!Plot)return;

    fclose(Plot);
}
void Write_SNR_Plot(double EbN0_dB, double SPA_SER, double SPA_BER,double MINSUMC_SER,double MINSUMC_BER)
{
    FILE* Plot = fopen(PLOT_FILE, "a");
    if (!Plot)return;

    fprintf(Plot, "%e,%e,%e,%e,%e\n", EbN0_dB, SPA_SER, SPA_BER, MINSUMC_SER, MINSUMC_BER);

    fclose(Plot);

}


void Each_SNR_Result(int NUM_TEST_CASE,int DECODER_MAX_ITER,double EbN0_dB)
{
    int SPA_Sucess_Time = 0;
    int SPA_Error_Time = 0;
    int Minsum_Sucess_Time = 0;
    int Minsum_Error_Time = 0;
    int MinsumC_Sucess_Time = 0;
    int MinsumC_Error_Time = 0;

    SPA->truebits = 0; SPA->falsebits = 0;
    Minsum->truebits = 0; Minsum->falsebits = 0;
    MinsumC->truebits = 0;MinsumC->falsebits = 0;

    Generate_TestData(NUM_TEST_CASE, N, M, EbN0_dB);

    FILE* TEST_DATA = fopen(TEST_DATA_FILE, "r");
    if (!TEST_DATA) return 1;

    double* channel_output = (double*)calloc(N , sizeof(double));
    double* channel_sigma = (double*)calloc(1,sizeof(double));
    int* SPA_decode_iteration = (int*)calloc(1,sizeof(int));
    int* MINSUMC_decode_iteration = (int*)calloc(1, sizeof(int));

    for (int testtime = 0; testtime < NUM_TEST_CASE; testtime++) 
    {
        double dummy;
        for (int j = 0; j < N; j++) fscanf(TEST_DATA, "%lf", &dummy);
        fscanf(TEST_DATA, "%lf", channel_sigma);
        for (int j = 0; j < N; j++) fscanf(TEST_DATA, "%lf", &channel_output[j]);

        bool isThisSPASucess = Decode_SumProduct(channel_sigma, SPA_decode_iteration, DECODER_MAX_ITER, channel_output);
        bool isThisMinsumCSusess = Decode_MinSumC(channel_sigma, MINSUMC_decode_iteration, DECODER_MAX_ITER, channel_output);

        if (isThisSPASucess == true) SPA_Sucess_Time += 1;else SPA_Error_Time += 1;
        if (isThisMinsumCSusess == true) MinsumC_Sucess_Time += 1;else MinsumC_Error_Time += 1;
    }

    //printf("SPA     SucessTime = %d    FalseTime = %d\n", SPA_Sucess_Time, SPA_Error_Time);
    //printf("MinsumC SucessTime = %d    FalseTime = %d\n", MinsumC_Sucess_Time, MinsumC_Error_Time);

    //printf("SPA     Truebits = %lld    Falsebits = %lld\n", SPA->truebits, SPA->falsebits);
    //printf("MinsumC Truebits = %lld    Falsebits = %lld\n", MinsumC->truebits, MinsumC->falsebits);

    double SPASegmentErrorRate = (double)SPA_Error_Time / (double)NUM_TEST_CASE;
    double MinsumCSegmentErrorRate = (double)MinsumC_Error_Time / (double)NUM_TEST_CASE;

    double SPA_BER = (double)SPA->falsebits / (double)(SPA->truebits + SPA->falsebits);
    double MinsumC_BER= (double)MinsumC->falsebits / (double)(MinsumC->truebits + MinsumC->falsebits);
    //printf("MAIN_TRUEBIT = %lld  FALSEBIT = %lld\nMAIN_ERROR_RATE = %g\n\n", GLOBAL_TRUEBIT, GLOBAL_FALSEBIT, GLOBAL_ERR_RATE);

    printf("IN EbN0_db=%3lf  SPA      SegmentErrorRate=%e  BitErrorRate=%e\n", EbN0_dB, SPASegmentErrorRate, SPA_BER);
    printf("IN EbN0_db=%3lf  Minsum-c SegmentErrorRate=%e  BitErrorRate=%e\n", EbN0_dB, MinsumCSegmentErrorRate, MinsumC_BER);
    printf("\n");

    Write_SNR_Plot(EbN0_dB, SPASegmentErrorRate, SPA_BER, MinsumCSegmentErrorRate, MinsumC_BER);
    // 釋放記憶體
    free(channel_output); free(channel_sigma);free(SPA_decode_iteration); free(MINSUMC_decode_iteration);
    fclose(TEST_DATA);

}




// --- 主程式 ---
int main(void) 
{
    init();
    Read_H_MatrixByAlist();

    const int num_test_cases = 10;
    const int decoder_iteration_max = 50;

    const double SNR_Start = 1.0;
    const double SNR_End = 6.0;
    const double step = 0.1;


    Create_SNR_Plot();

    for (double thisEbN0_db = SNR_Start;thisEbN0_db < SNR_End;thisEbN0_db += step)
    {
        Each_SNR_Result(num_test_cases, decoder_iteration_max, thisEbN0_db);
        
    }

    return 0;
}
