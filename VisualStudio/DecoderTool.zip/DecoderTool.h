#pragma once
#ifndef DECODERTOOL_H
#define DECODERTOOL_H


#ifndef PATH_PREFIX
#define PATH_PREFIX "C:\\Users\\09043\\OneDrive\\Python\\LDPC\\"
#endif

#define TEST_DATA_FILE PATH_PREFIX "test_data.txt"
#define H_MATRIX_FILE  PATH_PREFIX "GallagerH.txt"




// Defination
typedef struct {
    int row_weight;
    int offset; // �אּ�����b�@���}�C�����_�l����
} RowInfo;

typedef struct {
    int column_weight;
    int offset; // �אּ�����b�@���}�C�����_�l����
} ColInfo;

// �� extern ����L.c�ɮ׬ݨ�
extern int N, K, M;
extern RowInfo* H_rows;
extern ColInfo* H_cols;

extern int* H_row_places_flat;
extern int* H_col_places_flat;

extern long long GLOBAL_TRUEBIT, GLOBAL_FALSEBIT;

// DecoderTool.c
double SPA_phi(double x);
void Read_H_MatrixByAlist(void);
void Generate_TestData(const int count, int N, int M, double EbN0_dB);


// LDPC_Decoder
bool Decode_SumProduct(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output);


#endif // ! DECODERTOOL_H
