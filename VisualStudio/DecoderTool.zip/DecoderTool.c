#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"


int N = -1, K = -1, M = -1;
RowInfo* H_rows = NULL;
ColInfo* H_cols = NULL;

int* H_row_places_flat = NULL;
int* H_col_places_flat = NULL;

long long GLOBAL_TRUEBIT = 0, GLOBAL_FALSEBIT = 0;



// Read H Matrix
/*void Read_H_MatrixByAlist(void) {
    FILE* fp = fopen(H_MATRIX_FILE, "r");

    if (!fp) {
        printf("[SYSTEM] Open H matrix file failed: %s\n", H_MATRIX_FILE);
        return;
    }

    int max_col_weight = 0, max_row_weight = 0;
    int total_bits_count_by_col = 0, total_bits_count_by_row = 0;

    fscanf(fp, "%d %d", &N, &M);
    fscanf(fp, "%d %d", &max_col_weight, &max_row_weight);

    H_rows = (RowInfo*)malloc(M * sizeof(RowInfo));
    H_cols = (ColInfo*)malloc(N * sizeof(ColInfo));

    int temp = 0;

    // Ū���v���íp�ⰾ���q
    for (int i = 0; i < N; i++) {
        fscanf(fp, "%d", &H_cols[i].column_weight);
        H_cols[i].offset = total_bits_count_by_col;
        total_bits_count_by_col += H_cols[i].column_weight;
        printf("%d %d \n", H_cols[i].offset, total_bits_count_by_col);
    }
    for (int i = 0; i < M; i++) {
        fscanf(fp, "%d", &H_rows[i].row_weight);
        H_rows[i].offset = total_bits_count_by_row;
        total_bits_count_by_row += H_rows[i].row_weight;
        printf("%d %d \n", H_rows[i].offset, total_bits_count_by_row);
    }

    if (total_bits_count_by_row != total_bits_count_by_col)
        printf("[WARNING] Read H matrix \n");

    // ���t�s�򪺤@���Ŷ� (�j�p�� �`���*�̤j�v��)
    H_col_places_flat = (int*)malloc(total_bits_count_by_col * sizeof(int));
    H_row_places_flat = (int*)malloc(total_bits_count_by_row * sizeof(int));


    // Ū�� Column ��m��@���}�C
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < H_cols[i].column_weight; j++) {
            fscanf(fp, "%d", &temp);
            H_col_places_flat[H_cols[i].offset + j] = temp - 1;
            printf("%d H[%d] = %d\n", H_cols[i].offset + j, H_col_places_flat[H_cols[i].offset + j], temp - 1);
        }
    }
    // Ū�� Row ��m��@���}�C
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < H_rows[i].row_weight; j++) {
            fscanf(fp, "%d", &temp);
            H_row_places_flat[H_rows[i].offset + j] = temp - 1;
            printf("%d H[%d] = %d\n", H_rows[i].offset + j, H_col_places_flat[H_rows[i].offset + j], temp - 1);
        }
    }
    fclose(fp);
}*/
// --- �ɮ�Ū�� (Alist) �אּ�@���s�x ---
void Read_H_MatrixByAlist(void) 
{
    FILE* fp = fopen(H_MATRIX_FILE, "r");

    if (!fp) {
        printf("[SYSTEM] Open file failed: %s\n", H_MATRIX_FILE);
        return;
    }

    int max_col_weight = 0, max_row_weight = 0;
    fscanf(fp, "%d %d", &N, &M);
    fscanf(fp, "%d %d", &max_col_weight, &max_row_weight);

    H_rows = (RowInfo*)malloc(M * sizeof(RowInfo));
    H_cols = (ColInfo*)malloc(N * sizeof(ColInfo));

    // ���t�s�򪺤@���Ŷ� (�j�p�� �`���*�̤j�v��)
    H_col_places_flat = (int*)malloc(N * max_col_weight * sizeof(int));
    H_row_places_flat = (int*)malloc(M * max_row_weight * sizeof(int));

    // Ū���v���íp�ⰾ���q
    for (int i = 0; i < N; i++) {
        fscanf(fp, "%d", &H_cols[i].column_weight);
        H_cols[i].offset = i * max_col_weight;
    }
    for (int i = 0; i < M; i++) {
        fscanf(fp, "%d", &H_rows[i].row_weight);
        H_rows[i].offset = i * max_row_weight;
    }

    int temp = 0;
    // Ū�� Column ��m��@���}�C
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < H_cols[i].column_weight; j++) {
            fscanf(fp, "%d", &temp);
            H_col_places_flat[H_cols[i].offset + j] = temp - 1;
        }
    }
    // Ū�� Row ��m��@���}�C
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < H_rows[i].row_weight; j++) {
            fscanf(fp, "%d", &temp);
            H_row_places_flat[H_rows[i].offset + j] = temp - 1;
        }
    }
    fclose(fp);
}


// Generate Gaussian Test Data
double generate_gaussian(double sigma) 
{
    double u1 = (double)rand() / RAND_MAX;
    double u2 = (double)rand() / RAND_MAX;
    if (u1 <= 0.0) u1 = 1e-9;
    double z0 = sqrt(-2.0 * log(u1)) * cos(2.0 * 3.14159265358979323846 * u2);
    return z0 * sigma;
}

void Generate_TestData(const int count, int N, int M, double EbN0_dB) 
{
    FILE* f_out = fopen(TEST_DATA_FILE, "w");
    if (!f_out) {
        perror("[System] Failed to open Gaussian TestData file\n");
        return;
    }

    double rate = (double)(N - M) / N;
    double snr = pow(10.0, EbN0_dB / 10.0);
    double sigma = sqrt(1.0 / (2.0 * rate * snr));

    srand((unsigned int)time(NULL));
    int* codeword = (int*)calloc(N, sizeof(int));

    for (int c = 0; c < count; c++) {
        for (int i = 0; i < N; i++) fprintf(f_out, "%d%s", codeword[i], (i == N - 1) ? "" : " ");
        fprintf(f_out, "\n%lf\n", sigma);
        for (int i = 0; i < N; i++) {
            double s = (codeword[i] == 0) ? 1.0 : -1.0;
            double y = s + generate_gaussian(sigma);
            fprintf(f_out, "%lf%s", y, (i == N - 1) ? "" : " ");
        }
        fprintf(f_out, "\n");
    }
    free(codeword);
    fclose(f_out);
    printf("Successfully generated %d sets of data with Sigma: %lf\n", count, sigma);
}

// --- SPA �ѽX�֤߰Ƶ{�� ---
double SPA_phi(double x) {
    // Version 1 : only limit maxinum minimum
    if (x > 30.0)
        return 1e-13;
    if (x < 1e-13)
        return 30.0;

    double value = -log(tanh(x / 2.0));
    //printf("BEFOREPHI: x=%g value=%g\n", x, value);
    return value;
    // version 2 : Split to X(EX:8) point

}



