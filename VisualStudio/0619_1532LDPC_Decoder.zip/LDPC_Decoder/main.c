﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"

// calculus 15-4 Not include in Final

/*
    Update Record
    2026/05/17 18:07 Add Path Prefix
    2026/05/17 19:36

    SNR(dB) = Eb/n0(dB) - 3.01(dB)


*/

const int DECODER_ITERATION_MAX = 16;

void init(void)
{
    SPA = (Decoder*)calloc(1,sizeof(Decoder));
    MinsumC = (Decoder*)calloc(1,sizeof(Decoder));
    Minsum = (Decoder*)calloc(1,sizeof(Decoder));



}

void Create_SNR_Plot(void)
{
    FILE* Plot = fopen(PLOT_FILE, "w");
    if (!Plot)return;

    fclose(Plot);
}
void Write_SNR_Plot(Decoder *decoder)
{
    FILE* Plot = fopen(PLOT_FILE, "a");
    if (!Plot)return;

    if (decoder->FER == 0)decoder->FER = 1e-25;
    if (decoder->BER == 0)decoder->BER = 1e-25;

    // print first line
    //fprintf(Plot, "Type,EbN0(dB),SNR(dB),FER,BER,\n");
    if (decoder->decoder_type == 1){
        fprintf(Plot, "SPA,");
    }
    else if (decoder->decoder_type == 2) {
        fprintf(Plot, "MinsumC,");
    }
    else if (decoder->decoder_type == 3) {
        fprintf(Plot, "Minsum,");
    }
    else {
        fprintf(Plot, "ERROR,");
    }


    fprintf(Plot, "%lf,%lf,%d,%d,%e,%e,%lf\n",
        decoder->EbN0_dB, decoder->EbN0_dB - 3.0102999957,
        decoder->testcount,decoder->decoder_iteration_max,
        decoder->FER, decoder->BER,
        decoder->decode_time_ms);

    fclose(Plot);
}

void initDecoder(Decoder* decoder)
{
    decoder->truebits = 0;
    decoder->falsebits = 0;
    decoder->sucess_time = 0;
    decoder->error_time = 0;
    decoder->BER = 0;
    decoder->FER = 0;
}


void Each_SNR_Result(Decoder *decoder)
{
    initDecoder(decoder);

    CodeTimer Timer, TimerReadFile, GenerateGaussianTime;
    double TotalReadFileTime = 0, TotalDecodeTime = 0;
    
    timer_start(&GenerateGaussianTime);
    Generate_TestData(decoder->testcount, N, M, decoder->EbN0_dB);
    timer_stop(&GenerateGaussianTime);


    FILE* TEST_DATA = fopen(TEST_DATA_FILE, "r");
    if (!TEST_DATA) return 1;

    double* channel_output = (double*)calloc(N , sizeof(double));
    double* channel_sigma = (double*)calloc(1,sizeof(double));
    int* decode_iteration = (int*)calloc(1,sizeof(int));

    int theorem_bits = 0, theorem_fregments = 0;


    for (int testtime = 0; testtime < decoder->testcount; testtime++)
    {
        // sec 1 ReadTestData
        timer_start(&TimerReadFile);
        fscanf(TEST_DATA, "%lf", channel_sigma);
        for (int j = 0; j < N; j++) fscanf(TEST_DATA, "%lf", &channel_output[j]);
        timer_stop(&TimerReadFile);
        TotalReadFileTime += timer_get_ms(&TimerReadFile);

        // sec 2
        timer_start(&Timer);
        bool isThisSPASucess;
        if (decoder->decoder_type == 1){
            isThisSPASucess = Decode_SumProduct(channel_sigma, decode_iteration, decoder->decoder_iteration_max, channel_output);
        }
        else if (decoder->decoder_type == 2) {
            isThisSPASucess = Decode_MinSumC_New(channel_sigma, decode_iteration, decoder->decoder_iteration_max, channel_output);
        }
        else if (decoder->decoder_type == 3) {
            isThisSPASucess = Decode_MinSum(channel_sigma, decode_iteration, decoder->decoder_iteration_max, channel_output);
        }
        else {
            printf("ERROR cannot into decoder\n");
        }
        timer_stop(&Timer);
        TotalDecodeTime += timer_get_ms(&Timer);
    }
    decoder->decode_time_ms = TotalDecodeTime;

    Calculate_BERSER(decoder);
    if (decoder->BER == 0){
        theorem_bits = 999999999;
        theorem_fregments = 999999;
    }
    else {
        theorem_bits = (long long)(1 / decoder->BER * 500);
        theorem_fregments = (long long)(1 / decoder->BER * 500 / 3990);
    }

    printf("Time: %6.0lf(ms) Read Test File / Generate Gaussian Data Time: %6.0lf(ms) \n", TotalReadFileTime, timer_get_ms(&GenerateGaussianTime));
    printf("Time: %6.0lf(ms) EbN0_db=%3lf  FER=%5.4lf(T:%4d,F:%4d)  BER=%9.8lf(T:%9lld,F:%9lld)\n", TotalDecodeTime, decoder->EbN0_dB,
        decoder->FER, decoder->sucess_time, decoder->error_time, 
        decoder->BER, decoder->truebits, decoder->falsebits);
    printf("[理論,實際] bits=[%10d,%10d]  fregments=[%5d,%5d]\n", theorem_bits, decoder->testcount * 3990, theorem_fregments, decoder->testcount);

    printf("\n");

    Write_SNR_Plot(decoder);
    
    // 釋放記憶體
    free(channel_output); 
    free(channel_sigma);
    free(decode_iteration); 

    fclose(TEST_DATA);
}

void WriteDecoderStructure(int iteration_max, int type,  int TestCount,double EbN0_dB)
{
    if (type == 1)
    {
        SPA->EbN0_dB = EbN0_dB;
        SPA->testcount = TestCount;
        SPA->decoder_iteration_max = iteration_max;
        SPA->decoder_type = 1;
        Each_SNR_Result(SPA);
    }
    else if (type == 2)
    {
        MinsumC->EbN0_dB = EbN0_dB;
        MinsumC->testcount = TestCount;
        MinsumC->decoder_iteration_max = iteration_max;
        MinsumC->decoder_type = 2;
        Each_SNR_Result(MinsumC);
    }
    else if (type == 3)
    {
        Minsum->EbN0_dB = EbN0_dB;
        Minsum->testcount = TestCount;
        Minsum->decoder_iteration_max = iteration_max;
        Minsum->decoder_type = 3;
        Each_SNR_Result(Minsum);
    }
    else {
        printf("ERROR\n");
    }
}


void EZ_TEST(int DECODER_MAX_ITER)
{
    double* channel_output = (double*)calloc(N, sizeof(double));
    double* channel_sigma = (double*)calloc(1, sizeof(double));
    int* SPA_decode_iteration = (int*)calloc(1, sizeof(int));
    *channel_sigma = sqrt(0.5);

    double out[4000] = { 0.2,0.2, -0.9, 0.6, 0.5, -1.1, -0.4, -1.2 };
    //double out[4000] = { -1.5,0.8,-0.9,0.7,0.5,-1.1,-0.4,-1.2 };

    for (int i = 0;i < N;i++)channel_output[i] = out[i];
    
    bool isThisSPASucess = Decode_SumProduct(channel_sigma, SPA_decode_iteration, DECODER_MAX_ITER, channel_output);

}


void FINAL_RESULT(double parameter,bool is_SPA_ON,bool is_MinsumC_ON,bool is_Minsum_ON)
{
    int decoder_iteration_max = 16;
    // SPA
    if (is_SPA_ON)
    {
        WriteDecoderStructure(decoder_iteration_max, 1, 10, -1.0);
        WriteDecoderStructure(decoder_iteration_max, 1, 10, -0.75);
        WriteDecoderStructure(decoder_iteration_max, 1, 10, -0.5);
        WriteDecoderStructure(decoder_iteration_max, 1, 10, -0.25);
        WriteDecoderStructure(decoder_iteration_max, 1, 10, 0.0);
        WriteDecoderStructure(decoder_iteration_max, 1, 10, 0.2);
        WriteDecoderStructure(decoder_iteration_max, 1, 10, 0.4);
        WriteDecoderStructure(decoder_iteration_max, 1, 25, 0.6);
        WriteDecoderStructure(decoder_iteration_max, 1, 25, 0.8);
        WriteDecoderStructure(decoder_iteration_max, 1, 25, 1.0);
        WriteDecoderStructure(decoder_iteration_max, 1, 50, 1.2);
        WriteDecoderStructure(decoder_iteration_max, 1, 250, 1.4);
        WriteDecoderStructure(decoder_iteration_max, 1, 1000, 1.6);
        WriteDecoderStructure(decoder_iteration_max, 1, 1500, 1.65);
        WriteDecoderStructure(decoder_iteration_max, 1, 2000, 1.7);
        WriteDecoderStructure(decoder_iteration_max, 1, 3500, 1.75);
        WriteDecoderStructure(decoder_iteration_max, 1, 5000, 1.8);
        WriteDecoderStructure(decoder_iteration_max, 1, 10000, 1.85);
    }

    if (is_MinsumC_ON)
    {
        WriteDecoderStructure(decoder_iteration_max, 2, 10, -1.0);
        WriteDecoderStructure(decoder_iteration_max, 2, 10, -0.75);
        WriteDecoderStructure(decoder_iteration_max, 2, 10, -0.5);
        WriteDecoderStructure(decoder_iteration_max, 2, 10, -0.25);
        WriteDecoderStructure(decoder_iteration_max, 2, 10, 0.0);
        WriteDecoderStructure(decoder_iteration_max, 2, 10, 0.2);
        WriteDecoderStructure(decoder_iteration_max, 2, 10, 0.4);
        WriteDecoderStructure(decoder_iteration_max, 2, 25, 0.6);
        WriteDecoderStructure(decoder_iteration_max, 2, 25, 0.8);
        WriteDecoderStructure(decoder_iteration_max, 2, 25, 1.0);
        WriteDecoderStructure(decoder_iteration_max, 2, 25, 1.2);
        WriteDecoderStructure(decoder_iteration_max, 2, 50, 1.4);
        WriteDecoderStructure(decoder_iteration_max, 2, 100, 1.6);
        WriteDecoderStructure(decoder_iteration_max, 2, 500, 1.8);
        WriteDecoderStructure(decoder_iteration_max, 2, 1000, 1.9);
        WriteDecoderStructure(decoder_iteration_max, 2, 2000, 1.95);
        WriteDecoderStructure(decoder_iteration_max, 2, 5000, 2.0);
        WriteDecoderStructure(decoder_iteration_max, 2, 10000, 2.05);
        WriteDecoderStructure(decoder_iteration_max, 2, 25000, 2.1);
    }

    if (is_Minsum_ON)
    {
        WriteDecoderStructure(decoder_iteration_max, 3, 25, 2.0);
        WriteDecoderStructure(decoder_iteration_max, 3, 25, 2.2);
        WriteDecoderStructure(decoder_iteration_max, 3, 25, 2.4);
        WriteDecoderStructure(decoder_iteration_max, 3, 100, 2.6);
        WriteDecoderStructure(decoder_iteration_max, 3, 250, 2.8);
        WriteDecoderStructure(decoder_iteration_max, 3, 500, 2.9);
        WriteDecoderStructure(decoder_iteration_max, 3, 1000, 3.0);
        WriteDecoderStructure(decoder_iteration_max, 3, 2000, 3.1);
        WriteDecoderStructure(decoder_iteration_max, 3, 5000, 3.2);
        WriteDecoderStructure(decoder_iteration_max, 3, 10000, 3.3);
        WriteDecoderStructure(decoder_iteration_max, 3, 20000, 3.4);
        WriteDecoderStructure(decoder_iteration_max, 3, 25000, 3.5);
        WriteDecoderStructure(decoder_iteration_max, 3, 50000, 3.6);
    }
}


// --- 主程式 ---
int main(void) 
{
    init();

    CodeTimer readh;
    timer_start(&readh);
    Read_H_MatrixByAlist();
    timer_stop(&readh);
    printf("%lf\n", timer_get_ms(&readh));


    const int num_test_cases = 500;
    const int decoder_iteration_max = 16;

    const double EbN0_Start = 1.0;
    const double EbN0_End = 3.0;
    const double step = 0.2;


    Create_SNR_Plot();

    WriteDecoderStructure(decoder_iteration_max, 1, 20000, 1.87);
    //WriteDecoderStructure(decoder_iteration_max, 1, 15000, 1.85);


    //FINAL_RESULT(1.0, true, true, true);

    FINAL_RESULT(1.0, true, false, false);
    //FINAL_RESULT(1.0, false, true, false);
    //FINAL_RESULT(1.0, false, false, true);


    //for (double thisEbN0_db = -1.0;thisEbN0_db < 1.0;thisEbN0_db += 0.25){ Each_SNR_Result(10, decoder_iteration_max, thisEbN0_db);  }
    //for (double thisEbN0_db = 1.0; thisEbN0_db < 2.5; thisEbN0_db += 0.15) { Each_SNR_Result(num_test_cases, decoder_iteration_max, thisEbN0_db); }
    //for (double thisEbN0_db = 2.5; thisEbN0_db < 4.0; thisEbN0_db += 0.25) { Each_SNR_Result(num_test_cases, decoder_iteration_max, thisEbN0_db); }

    //const double thisEbN0_db = 6.3; Each_SNR_Result(num_test_cases, decoder_iteration_max, thisEbN0_db);  

    //EZ_TEST(decoder_iteration_max);

    //FREE_H_MatrixByAlist();
    printf("Total Test Bit %d\n", N * num_test_cases);
    printf("Total Test Count:%d\n", (int)((EbN0_End - EbN0_Start) / step) * num_test_cases);

    return 0;
}
