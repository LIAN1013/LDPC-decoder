﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"

// calculus 15-4 Not include in Final

/*
    Update Record
    2026/05/17 18:07 Add Path Prefix
    2026/05/17 19:36

*/

void init(void)
{
    SPA = (Decoder*)calloc(1,sizeof(Decoder));
    MinsumC = (Decoder*)calloc(1,sizeof(Decoder));
    Minsum = (Decoder*)calloc(1,sizeof(Decoder));
}

void Create_SNR_Plot(void)
{
    FILE* Plot = fopen(PLOT_FILE, "w");
    if (!Plot)return;

    fclose(Plot);
}
void Write_SNR_Plot(double EbN0_dB, double SPA_SER, double SPA_BER,double MINSUMC_SER,double MINSUMC_BER, double MINSUM_SER, double MINSUM_BER)
{
    FILE* Plot = fopen(PLOT_FILE, "a");
    if (!Plot)return;

    fprintf(Plot, "%e,%e,%e,%e,%e,%e,%e\n", EbN0_dB, SPA_SER, SPA_BER, MINSUMC_SER, MINSUMC_BER, MINSUM_SER, MINSUM_BER);

    fclose(Plot);

}


void Each_SNR_Result(int NUM_TEST_CASE,int DECODER_MAX_ITER,double EbN0_dB)
{
    memset(SPA, 0, sizeof(Decoder));
    memset(MinsumC, 0, sizeof(Decoder));
    memset(Minsum, 0, sizeof(Decoder));

    CodeTimer TimerSPA, TimerMinsum, TimerMinsumC, TimerReadFile, GenerateGaussianTime;
    double Timer[10] = { 0,0,0,0,0,0,0,0,0,0 };
    

    timer_start(&GenerateGaussianTime);
    Generate_TestData(NUM_TEST_CASE, N, M, EbN0_dB);
    timer_stop(&GenerateGaussianTime);


    FILE* TEST_DATA = fopen(TEST_DATA_FILE, "r");
    if (!TEST_DATA) return 1;

    double* channel_output = (double*)calloc(N , sizeof(double));
    double* channel_sigma = (double*)calloc(1,sizeof(double));
    int* SPA_decode_iteration = (int*)calloc(1,sizeof(int));
    int* MINSUMC_decode_iteration = (int*)calloc(1, sizeof(int));
    int* MINSUM_decode_iteration = (int*)calloc(1, sizeof(int));

    for (int testtime = 0; testtime < NUM_TEST_CASE; testtime++) 
    {
        // sec 1 ReadTestData
        timer_start(&TimerReadFile);
        fscanf(TEST_DATA, "%lf", channel_sigma);
        for (int j = 0; j < N; j++) fscanf(TEST_DATA, "%lf", &channel_output[j]);
        timer_stop(&TimerReadFile);
        Timer[0] += timer_get_ms(&TimerReadFile);

        // sec 2 SPA
        timer_start(&TimerSPA);
        bool isThisSPASucess = Decode_SumProduct(channel_sigma, SPA_decode_iteration, DECODER_MAX_ITER, channel_output);
        timer_stop(&TimerSPA);
        Timer[1] += timer_get_ms(&TimerSPA);

        // sec 3 minsumC
        timer_start(&TimerMinsumC);
        //bool isThisMinsumCSusess = Decode_MinsumC_Ver0521(channel_sigma, MINSUMC_decode_iteration, DECODER_MAX_ITER, channel_output);
        timer_stop(&TimerMinsumC);
        Timer[2] += timer_get_ms(&TimerMinsumC);
        
        // sec 4 
        timer_start(&TimerMinsum);
        //bool isThisMinsumSusess = Decode_MinSum(channel_sigma, MINSUM_decode_iteration, DECODER_MAX_ITER, channel_output);
        timer_stop(&TimerMinsum);
        Timer[3] += timer_get_ms(&TimerMinsum);
    }

    Calculate_BERSER(SPA);
    //Calculate_BERSER(MinsumC);
    //Calculate_BERSER(Minsum);

    printf("Time: %6.0lf(ms) Read Test File    /   Generate Gaussian Data Time: %6.0lf(ms)\n", Timer[0],timer_get_ms(&GenerateGaussianTime));
    printf("Time: %6.0lf(ms) EbN0_db=%3lf  SPA      SegmentErrorRate=%5.4lf  BitErrorRate=%13.12lf\n",Timer[1], EbN0_dB, SPA->FER, SPA->BER);
    //printf("Time: %6.0lf(ms) EbN0_db=%3lf  Minsum-c SegmentErrorRate=%5.4lf  BitErrorRate=%13.12lf\n",Timer[2], EbN0_dB, MinsumC->FER, MinsumC->BER);
    //printf("Time: %6.0lf(ms) EbN0_db=%3lf  Minsum   SegmentErrorRate=%5.4lf  BitErrorRate=%13.12lf\n",Timer[3], EbN0_dB, Minsum->FER, Minsum->BER);
    printf("\n");

    Write_SNR_Plot(EbN0_dB, 
        SPA->FER, SPA->BER, 
        MinsumC->FER, MinsumC->BER, 
        Minsum->FER, Minsum->BER);
    
    // 釋放記憶體
    free(channel_output); free(channel_sigma);
    free(SPA_decode_iteration); free(MINSUMC_decode_iteration); free(MINSUM_decode_iteration);
    fclose(TEST_DATA);
}




// --- 主程式 ---
int main(void) 
{
    init();

    CodeTimer readh;
    timer_start(&readh);
    Read_H_MatrixByAlist();
    timer_stop(&readh);
    printf("%lf\n", timer_get_ms(&readh));


    const int num_test_cases = 2000;
    const int decoder_iteration_max = 20;

    const double SNR_Start = 0.0;
    const double SNR_End = 4.0;
    const double step = 1.0;


    Create_SNR_Plot();

    //for (double thisEbN0_db = SNR_Start;thisEbN0_db <= SNR_End;thisEbN0_db += step){
    //    Each_SNR_Result(num_test_cases, decoder_iteration_max, thisEbN0_db);  
    //}
    const double thisEbN0_db = 4.3;
    Each_SNR_Result(num_test_cases, decoder_iteration_max, thisEbN0_db);  

    //FREE_H_MatrixByAlist();
    printf("Total Test Bit %d\n", N * num_test_cases);
    printf("Total Test Count:%d\n", (int)((SNR_End - SNR_Start) / step) * num_test_cases);

    return 0;
}
