#pragma once
#ifndef DECODERTOOL_H
#define DECODERTOOL_H


#ifndef PATH_PREFIX
#define PATH_PREFIX "C:\\Users\\09043\\OneDrive\\Python\\LDPC\\"
#endif

#define TEST_DATA_FILE PATH_PREFIX "test_data.txt"
#define H_MATRIX_FILE  PATH_PREFIX "GallagerH.txt"
#define PLOT_FILE PATH_PREFIX "plot.csv"

// �w�q�p�ɾ����c��
typedef struct {
    struct timespec start_time;
    struct timespec end_time;
    bool is_running;
} CodeTimer;

// �ƨ禡���f�ŧi
void timer_start(CodeTimer* timer);
void timer_stop(CodeTimer* timer);
double timer_get_ms(CodeTimer* timer);
double timer_get_sec(CodeTimer* timer);

// Defination
typedef struct {
    int row_weight;
    int offset; // �אּ�����b�@���}�C�����_�l����
} RowInfo;

typedef struct {
    int column_weight;
    int offset; // �אּ�����b�@���}�C�����_�l����
} ColInfo;

typedef struct {
    long long truebits;
    long long falsebits;
    double BER;
    int sucess_time;
    int error_time;
    double FER;

    int decoder_iteration_max;
    // type1=SPA type2=MinsumC type3=Minsum
    int decoder_type;

    double EbN0_dB;
    double SNR_dB;
    int testcount;
    double decode_time_ms;
    bool isOperatingInThisEbN0;
} Decoder;

typedef struct
{
    double minBetaValue;
    int minBetaPosition;
} minBeta;


// �� extern ����L.c�ɮ׬ݨ�
extern int N, K, M;
extern int max_col_weight, max_row_weight;
extern RowInfo* H_rows;
extern ColInfo* H_cols;

extern int* H_row_places_flat;
extern int* H_col_places_flat;

extern Decoder* SPA;
extern Decoder* Minsum;
extern Decoder* MinsumC;


// DecoderTool.c
void Read_H_MatrixByAlist(void);
void FREE_H_MatrixByAlist(void);
void Printf_H_Matrix(char* output);

void Generate_TestData(const int count, int N, int M, double EbN0_dB);
void Calculate_BERSER(Decoder* input_data);


// LDPC_Decoder
bool Decode_SumProduct(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output);

bool Decode_MinSumC_OK(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output);
bool Decode_MinSumC_New(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* LLR_Current);


bool Decode_MinSum(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output);
bool Decode_NormalizedMinSum(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output);



#endif // ! DECODERTOOL_H
