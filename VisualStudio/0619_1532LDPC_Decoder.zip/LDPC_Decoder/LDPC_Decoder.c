﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"

// initial LLR=2yi/(sigma^2) data
void initial(double* channel_sigma, double* channel_output, double* LLR_ChannelCurrent, double* LLR_FinalResult)
{
    for (int i = 0; i < N; i++)
    {
        LLR_ChannelCurrent[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_FinalResult[i] = LLR_ChannelCurrent[i];
    }
}


// --- SPA 解碼核心副程式 ---
double SPA_phi(double x) 
{
    // Version 1 : only limit maxinum minimum
    
    if (x > 30.0)return 1e-13;
    if (x < 1e-13)return 30;

    double value = -log(tanh(x / 2.0));
    //printf("BEFOREPHI: x=%g value=%g\n", x, value);
    return value;
    
    // version 2 : Split to X(EX:8) point

}



// --- log domain decoder main function ---
bool Decode_SumProduct(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output)
{
    //printf("SUMPRODUCT\n");
    double* LLR_Channel = (double*)calloc(N, sizeof(double));
    double* LLR_Current = (double*)calloc(N, sizeof(double)); // 這裡永遠維持「當前最新、包含自身的完整總和」
    int* Ci = (int*)calloc(N, sizeof(int));

    // 取得 H 矩陣總非零元素個數（總邊數）
    int Total_Edges = H_rows[M - 1].offset + H_rows[M - 1].row_weight;
    // 這是唯一需要多開的線性陣列，用來記錄上一輪 Check Node 丟給 Variable Node 的數值
    double* R_ij = (double*)calloc(Total_Edges, sizeof(double));

    // 初始化
    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
    }

    *decoder_iteration = 0;
    long long truebit = 0, falsebit = 0;

    while (*decoder_iteration < decoder_max_iteration)
    {
        truebit = 0, falsebit = 0;

        // --- Check Node Update ---
        for (int i = 0; i < M; i++)
        {
            int TotalNegativeCount = 0;
            double TotalPhi = 0;
            int offset = H_rows[i].offset;

            // 【第一階段】：用當前完整總和扣除這條邊上一次的舊訊息，現場還原純淨不含自身的 beta
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];

                // 數學核心：beta = 完整總和 - 上一輪這個 Cnode 給他的值
                double beta = LLR_Current[col_idx] - R_ij[offset + j];

                if (beta < 0) TotalNegativeCount++;
                TotalPhi += SPA_phi(fabs(beta));
            }

            // 【第二階段】：利用大總和減去自己的技巧，更新 R_ij，並「同步差額」回總和
            for (int j = 0; j < H_rows[i].row_weight; j++)
            {
                int col_idx = H_row_places_flat[offset + j];
                double beta = LLR_Current[col_idx] - R_ij[offset + j];

                // 排除自身的正確正負號邏輯
                int actual_neg_count = (beta < 0) ? (TotalNegativeCount - 1) : TotalNegativeCount;
                int sign = (actual_neg_count % 2 == 0) ? 1 : -1;

                double total_phi_except_phi = TotalPhi - SPA_phi(fabs(beta));
                if (total_phi_except_phi < 1e-13) total_phi_except_phi = 1e-13;
                if (total_phi_except_phi > 30.0) total_phi_except_phi = 30.0;

                // 算出這一輪全新的、不含當前 Cnode 自身的排他新訊息
                double new_R_ij = sign * SPA_phi(total_phi_except_phi);

                // 【關鍵加速優化】：直接把新舊訊息的「價差」補回 LLR_Current
                // 這樣 LLR_Current 就會無時無刻維持在最新的「完整總和（包含自身）」狀態
                LLR_Current[col_idx] += (new_R_ij - R_ij[offset + j]);

                // 覆蓋舊訊息，留給下一輪疊代扣除使用
                R_ij[offset + j] = new_R_ij;
            }
        }

        // --- 變數節點硬決策 ---
        // 此時 LLR_Current 已經在上面即時更新好了，就是包含所有人完整訊息的最新判決值
        for (int i = 0; i < N; i++)
        {
            Ci[i] = (LLR_Current[i] >= 0) ? 0 : 1;
            if (Ci[i] == 0) truebit++; else falsebit++;
        }
        //if (falsebit == 3990)printf("%d %lf,%d %lf,%d %lf,%d %lf\n", Ci[0], LLR_Current[0], Ci[1], LLR_Current[1], Ci[2], LLR_Current[2], Ci[3], LLR_Current[3]);

        // --- 偶校驗碼判斷 ---
        bool isAllZero = true;
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) isAllZero = false;
        }

        if (isAllZero == true) {
            SPA->truebits += truebit;
            SPA->falsebits += falsebit;
            SPA->sucess_time += 1;
            //if (falsebit == 3990)printf("SYSTEM:ERROR\n");

            free(LLR_Channel); free(LLR_Current); free(Ci); free(R_ij);
            return true;
        }

        *decoder_iteration += 1;
    }

    SPA->truebits += truebit;
    SPA->falsebits += falsebit;
    SPA->error_time += 1;

    free(LLR_Channel); free(LLR_Current); free(Ci); free(R_ij);
    return false;
}

// --- log domain decoder main function ---
bool Decode_SumProductOLD(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output) 
{
    //Read_H_MatrixByAlist();
    //Printf_H_Matrix("SPA");

    double* LLR_Current = (double*)calloc(N , sizeof(double));
    double* LLR_FinalResult = (double*)calloc(N , sizeof(double));
    double* phibeta = (double*)calloc(N , sizeof(double));
    int* Ci = (int*)calloc(N , sizeof(int));
    double* ReturnTotal = (double*)calloc(N, sizeof(double));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    // init
    for (int i = 0; i < N; i++) {
        LLR_Current[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_FinalResult[i] = LLR_Current[i];
        //printf("%lf %lf\n", channel_output[i], LLR_Current[i]);
    }
    //printf("\n");

    *decoder_iteration = 0;
    long long truebit = 0, falsebit = 0;

    while (*decoder_iteration < decoder_max_iteration) 
    {
        truebit = 0, falsebit = 0;
        memset(ReturnTotal, 0, N * sizeof(double));
        memset(ReturnTotalExceptI, 0, N * sizeof(double));

        for (int j = 0; j < N; j++) 
        {
            phibeta[j] = SPA_phi(fabs(LLR_Current[j]));
        }

        //for (int j = 0; j < N; j++) printf("Precaculate: LLR_CURRENT= %lf   phibeta[%d]=%lf  fabs=%lf out=%lf\n", LLR_Current[j], j, phibeta[j],fabs(LLR_Current[j]), SPA_phi(fabs(LLR_Current[j])));

        // Check Node Update (使用一維陣列存取)
        for (int i = 0; i < M; i++) 
        {
            int TotalNegativeCount = 0;
            double TotalPhi = 0;
            int offset = H_rows[i].offset;

            int* isNegative = (int*)calloc(H_rows[i].row_weight, sizeof(int));
            for (int j = 0;j < H_rows[i].row_weight;j++) { isNegative[j] = 1; }

            
            //printf("\nITERATION %d-%d FIRST SETP\n", *decoder_iteration, i);
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j]; // 改成一維索引
                if (LLR_Current[col_idx] < 0) {
                    TotalNegativeCount++;
                    isNegative[j] = -1;
                }
                TotalPhi += phibeta[col_idx];
                //printf("TOTALPHI=%lf phibeta[%d]%lf\n", TotalPhi,col_idx, phibeta[col_idx]);
            }
            
            //printf("\nITERATION %d-%d SECOND SETP\n", *decoder_iteration, i);
            for (int j = 0; j < H_rows[i].row_weight; j++) 
            {
                int actual_neg_count = (isNegative[j] == -1) ? (TotalNegativeCount - 1) : TotalNegativeCount;
                int actual_sign = (actual_neg_count % 2 == 0) ? 1 : -1;
                int total_sign= (TotalNegativeCount % 2 == 0) ? 1 : -1;

                int col_idx = H_row_places_flat[offset + j];
                double total_phi_except_phi = TotalPhi - phibeta[col_idx];
                //printf("total_phi_except_phi=%lf  TotalPhi=%lf  phibeta[%d]=%lf\n", total_phi_except_phi, TotalPhi, col_idx, phibeta[col_idx]);


                double return_value = total_sign * SPA_phi(TotalPhi);
                double returnValueExceptI = actual_sign * SPA_phi(total_phi_except_phi);
                //printf("%d TotalPhiExceptI->%llf isNegative[j]=%d  SPA_phi=%lf \n", j, total_phi_except_phi, isNegative[j], SPA_phi(total_phi_except_phi));
                ReturnTotal[col_idx] += return_value;
                ReturnTotalExceptI[col_idx] += returnValueExceptI;
                //printf("Row %d column %d ReturnValue->%llf Row %d column %d ReturnValueExcept->%llf\n", i + 1, col_idx + 1, return_value, i + 1, col_idx + 1, returnValueExceptI);

            }

            //for (int j = 0;j < N;j++){printf("column=%d TOTAL:%llf  TOTALEXCEPT:%llf\n", j + 1, ReturnTotal[j], ReturnTotalExceptI[j]);}printf("\n");
            free(isNegative);
        }

        //printf("STEP3 in %d iteration\n", *decoder_iteration);
        for (int i = 0; i < N; i++) 
        {
            //printf("LLR Before->%llf   ", LLR_Current[i]);
            LLR_FinalResult[i] = LLR_Current[i] + ReturnTotal[i];
            LLR_Current[i] += ReturnTotalExceptI[i];
            //printf("LLR After->%llf\n", LLR_Current[i]);

            Ci[i] = (LLR_FinalResult[i] > 0) ? 0 : 1;
            if (Ci[i] == 0) truebit++; else falsebit++;
            //printf("RESULT:%d  FINALRESULT:LLR(Qi)=%llf  LLR(qij)=%llf Ci[%d]=%d\n", i, LLR_FinalResult[i], LLR_Current[i], i, Ci[i]);
        }
        //printf("\n");

        bool isAllZero = true;
        // 校驗 (使用一維陣列存取)
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) isAllZero = false;
        }

        if (isAllZero == true) {
            SPA->truebits += truebit; 
            SPA->falsebits += falsebit;
            SPA->sucess_time += 1;

            free(LLR_Current); free(LLR_FinalResult); free(phibeta); free(Ci); free(ReturnTotal); free(ReturnTotalExceptI);
            //FREE_H_MatrixByAlist();
            return true;
        }

        *decoder_iteration += 1;
    }
    SPA->truebits += truebit; 
    SPA->falsebits += falsebit;
    SPA->error_time += 1;

    free(LLR_Current); free(LLR_FinalResult); free(phibeta); free(Ci); free(ReturnTotal); free(ReturnTotalExceptI);
    //FREE_H_MatrixByAlist();
    return false;
}




// 定義 Box-Plus 運算 (Min-Sum + Correction Factor)
double box_plus(double L1, double L2) {
    double sign1 = (L1 < 0) ? -1.0 : 1.0;
    double sign2 = (L2 < 0) ? -1.0 : 1.0;
    double abs1 = fabs(L1);
    double abs2 = fabs(L2);
    double min_val = (abs1 < abs2) ? abs1 : abs2;

    // --- 方法 A：精確修正項 s(x, y) 
    double sum_abs = fabs(L1 + L2);
    double diff_abs = fabs(L1 - L2);
    //double correction = log(1.0 + exp(-sum_abs)) - log(1.0 + exp(-diff_abs));

     // --- 方法 B：近似修正項 s~(x, y) (速度較快) ---
    double correction = 0.0;
    double c = 0.5; // 常數 c 通常設為 0.5 左右
    if (sum_abs < 2.0 && diff_abs > 2.0 * sum_abs) {
        correction = c;
    }else if (diff_abs < 2.0 && sum_abs > 2.0 * diff_abs) {
        correction = -c;
    }
    

    return sign1 * sign2 * min_val + correction;
}
double s_tilde(double correctionValue, double x, double y)
{
    if (fabs(x + y) < 2 && fabs(x - y) > 2 * fabs(x + y))
        return correctionValue;
    else if (fabs(x - y) < 2 && fabs(x + y) > 2 * fabs(x - y))
        return -correctionValue;
    else
        return 0;
}


// --- minsum-c decoder main function ---
/*bool Decode_MinSumC(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output)
{
    //Read_H_MatrixByAlist();
    //Printf_H_Matrix("MinsumC");

    double* LLR_Channel = (double*)calloc(N, sizeof(double));
    double* LLR_Current = (double*)calloc(N, sizeof(double));
    int* Ci = (int*)calloc(N, sizeof(int));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    // 準備 Forward-Backward 陣列，用於 Check Node 內部遞迴計算 Box-Plus
    // 大小配置為 N 是最安全的上限 (確保不會超過最大的 row_weight)
    double* forward = (double*)calloc(N, sizeof(double));
    double* backward = (double*)calloc(N, sizeof(double));

    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
    }

    *decoder_iteration = 0;

    long long truebit = 0, falsebit = 0;
    while (*decoder_iteration < decoder_max_iteration) 
    {
        truebit = 0, falsebit = 0;

        // 每次迭代歸零 Check Node 的外在訊息累積
        memset(ReturnTotalExceptI, 0, N * sizeof(double));

        // --- Check Node Update (使用 Forward-Backward 計算 Box-Plus) ---
        for (int i = 0; i < M; i++) {
            int offset = H_rows[i].offset;
            int row_weight = H_rows[i].row_weight;

            if (row_weight == 0) continue; // 防呆處理

            // 1. 計算 Forward 陣列 (從左加到右)
            forward[0] = LLR_Current[H_row_places_flat[offset]];
            for (int j = 1; j < row_weight; j++) {
                double L_next = LLR_Current[H_row_places_flat[offset + j]];
                forward[j] = box_plus(forward[j - 1], L_next);
            }

            // 2. 計算 Backward 陣列 (從右加到左)
            backward[row_weight - 1] = LLR_Current[H_row_places_flat[offset + row_weight - 1]];
            for (int j = row_weight - 2; j >= 0; j--) {
                double L_prev = LLR_Current[H_row_places_flat[offset + j]];
                backward[j] = box_plus(backward[j + 1], L_prev);
            }

            // 3. 組合出 Exclude-I (排除自身) 的訊息並送回 Variable Node
            for (int j = 0; j < row_weight; j++) {
                double msg_out;
                if (j == 0) {
                    msg_out = backward[1]; // 第一個節點，只需後向陣列
                }
                else if (j == row_weight - 1) {
                    msg_out = forward[row_weight - 2]; // 最後一個節點，只需前向陣列
                }
                else {
                    msg_out = box_plus(forward[j - 1], backward[j + 1]); // 中間節點，前向 + 後向
                }

                int col_idx = H_row_places_flat[offset + j];
                ReturnTotalExceptI[col_idx] += msg_out;
            }
        }

        bool isAllZero = true;

        // --- Variable Node Update & Hard Decision ---
        for (int i = 0; i < N; i++) {
            double LLR_FinalResult = LLR_Channel[i] + ReturnTotalExceptI[i];
            Ci[i] = (LLR_FinalResult > 0) ? 0 : 1;

            if (Ci[i] == 0) {
                truebit++;
            }
            else {
                falsebit++;
            }

            LLR_Current[i] = LLR_FinalResult;
        }

        // --- Syndrome Check ---
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break;
            }
        }

        if (isAllZero == true) {
            MinsumC->truebits += truebit;
            MinsumC->falsebits += falsebit;
            MinsumC->sucess_time += 1;

            free(LLR_Channel);
            free(LLR_Current);
            free(Ci);
            free(ReturnTotalExceptI);
            free(forward);
            free(backward);
            //FREE_H_MatrixByAlist();

            return true;
        }
        *decoder_iteration += 1;
    }
    // 如果程式跑到這裡，代表把所有迭代次數都用光了還是沒解出來 (解碼失敗)
    // 結算最後一次迭代的錯誤狀況
    MinsumC->truebits += truebit;
    MinsumC->falsebits += falsebit;
    MinsumC->error_time += 1;

    free(LLR_Channel);
    free(LLR_Current);
    free(Ci);
    free(ReturnTotalExceptI);
    free(forward);
    free(backward);
    //FREE_H_MatrixByAlist();

    return false;

}*/

bool Decode_MinSumC_New(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* LLR_Current)
{
    if (N == -1 || M == -1) {
        printf("[SYSTEM] READ Alist Failed\n");
        return false;
    }

    double* LLR_FinalResult = (double*)malloc(N * sizeof(double));
    int* Ci = (int*)malloc(N * sizeof(int));
    double* ReturnTotal = (double*)malloc(N * sizeof(double));

    // 計算總邊數 (動態對齊你的 H_rows 結構)
    int total_row_edges = H_rows[M - 1].offset + H_rows[M - 1].row_weight;
    double* R_c2v = (double*)calloc(total_row_edges, sizeof(double));
    double* Q_v2c = (double*)malloc(total_row_edges * sizeof(double));
    double* LLR_Channel = (double*)malloc(total_row_edges * sizeof(double));

    // 初始化 LLR
    double sigma_sq = (*channel_sigma) * (*channel_sigma);

    // 優化 1：初始化改用線性遞增指標 edge_idx，讓記憶體寫入連續化
    int edge_idx = 0;
    for (int i = 0; i < M; i++)
    {
        int weight = H_rows[i].row_weight;
        for (int j = 0; j < weight; j++)
        {
            int v_node = H_row_places_flat[edge_idx];
            Q_v2c[edge_idx] = 2.0 * LLR_Current[v_node] / sigma_sq;
            LLR_Channel[edge_idx] = Q_v2c[edge_idx];
            edge_idx++;
        }
    }

    *decoder_iteration = 0;
    double correctionValue = 0.75;
    bool isAllZero = true;

    // --- 解碼主迴圈 ---
    while (*decoder_iteration < decoder_max_iteration)
    {
        for (int i = 0; i < N; i++) ReturnTotal[i] = 0.0;

        /// --- STEP 1: CHECK NODE UPDATE (全面改用線性遞增指標) ---
        edge_idx = 0; // 每一輪疊代開始，重新從第 0 條邊出發
        for (int i = 0; i < M; i++)
        {
            int weight = H_rows[i].row_weight;

            int TotalNegativeCount = 0;
            minBeta first, second, third;
            first.minBetaValue = second.minBetaValue = third.minBetaValue = 1e100;

            // 第一次 Loop：直接依序讀取連續的記憶體區段
            for (int j = 0; j < weight; j++)
            {
                int k = edge_idx + j; // 計算這條邊在全域陣列中的絕對位置
                int v_node = H_row_places_flat[k];
                double v_message = Q_v2c[k];

                if (v_message < 0) TotalNegativeCount++;

                double tempValue = fabs(v_message);
                if (tempValue < first.minBetaValue) {
                    third = second; second = first;
                    first.minBetaValue = tempValue; first.minBetaPosition = v_node;
                }
                else if (tempValue < second.minBetaValue) {
                    third = second;
                    second.minBetaValue = tempValue; second.minBetaPosition = v_node;
                }
                else if (tempValue < third.minBetaValue) {
                    third.minBetaValue = tempValue;
                }
            }

            // 第二次 Loop：加入修正項並發送
            for (int j = 0; j < weight; j++)
            {
                int k = edge_idx + j;
                int tempPosition = H_row_places_flat[k];
                double v_message = Q_v2c[k];

                int self_sign = (v_message < 0) ? -1 : 1;
                int alpha = (TotalNegativeCount % 2 == 0) ? 1 : -1;
                int exclusion_alpha = alpha * self_sign;

                double pureMinValues = 0.0;
                double s_correction = 0.0;

                if (tempPosition == first.minBetaPosition) {
                    s_correction = s_tilde(correctionValue, second.minBetaValue, third.minBetaValue);
                    pureMinValues = second.minBetaValue;
                }
                else if (tempPosition == second.minBetaPosition) {
                    s_correction = s_tilde(correctionValue, first.minBetaValue, third.minBetaValue);
                    pureMinValues = first.minBetaValue;
                }
                else {
                    s_correction = s_tilde(correctionValue, first.minBetaValue, second.minBetaValue);
                    pureMinValues = first.minBetaValue;
                }

                double new_R = exclusion_alpha * (pureMinValues + s_correction);
                R_c2v[k] = new_R;
                ReturnTotal[tempPosition] += new_R;
            }

            edge_idx += weight; // 💡 關鍵：處理完一個 Check Node，直接跳過該列的權重長度
        }

        /// --- STEP 2: VARIABLE NODE UPDATE & HARD DECISION ---
        for (int i = 0; i < N; i++)
        {
            //double LLR_intrinsic = 2.0 * LLR_Current[i] / sigma_sq;
            LLR_FinalResult[i] = LLR_Channel[i] + ReturnTotal[i];
            Ci[i] = (LLR_FinalResult[i] >= 0.0) ? 0 : 1;
        }

        // 優化 2：更新 Q_v2c 邊訊息時，同步改用線性累加指標 edge_idx
        edge_idx = 0;
        for (int i = 0; i < M; i++)
        {
            int weight = H_rows[i].row_weight;
            for (int j = 0; j < weight; j++)
            {
                int v_node = H_row_places_flat[edge_idx];
                Q_v2c[edge_idx] = LLR_FinalResult[v_node] - R_c2v[edge_idx];
                edge_idx++;
            }
        }

        /// --- STEP 3: PARITY CHECK (同步改用線性累加指標優化) ---
        isAllZero = true;
        edge_idx = 0;
        for (int i = 0; i < M; i++)
        {
            int decision = 0;
            int weight = H_rows[i].row_weight;
            for (int j = 0; j < weight; j++) {
                decision += Ci[H_row_places_flat[edge_idx++]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break;
            }
        }

        if (isAllZero){
            break;
        }
        *decoder_iteration += 1;
    }

    /// --- 終點線記分板 ---
    long long truebit = 0;
    long long falsebit = 0;

    for (int i = 0; i < N; i++)
    {
        if (Ci[i] == 0) {
            truebit++;
        }
        else {
            falsebit++;
        }
    }

    MinsumC->truebits += truebit;
    MinsumC->falsebits += falsebit;
    if (isAllZero) {
        MinsumC->sucess_time += 1;
    }
    else {
        MinsumC->error_time += 1;
    }


    free(LLR_FinalResult); free(Ci); free(ReturnTotal); free(R_c2v); free(Q_v2c);
    free(LLR_Channel);
    return isAllZero;
}


//  DO NOT CHANGE!!!
bool Decode_MinSumC_OK(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* LLR_Current)
{
    if (N == -1 || M == -1) {
        printf("[SYSTEM] READ Alist Failed\n");
        return false;
    }

    double* LLR_FinalResult = (double*)malloc(N * sizeof(double));
    int* Ci = (int*)malloc(N * sizeof(int));
    double* ReturnTotal = (double*)malloc(N * sizeof(double));

    // 計算總邊數 (動態對齊你的 H_rows 結構)
    int total_row_edges = H_rows[M - 1].offset + H_rows[M - 1].row_weight;
    double* R_c2v = (double*)calloc(total_row_edges, sizeof(double));
    double* Q_v2c = (double*)malloc(total_row_edges * sizeof(double));

    // 初始化 LLR
    double sigma_sq = (*channel_sigma) * (*channel_sigma);

    // 優化 1：初始化改用線性遞增指標 edge_idx，讓記憶體寫入連續化
    int edge_idx = 0;
    for (int i = 0; i < M; i++)
    {
        int weight = H_rows[i].row_weight;
        for (int j = 0; j < weight; j++)
        {
            int v_node = H_row_places_flat[edge_idx];
            Q_v2c[edge_idx] = 2.0 * LLR_Current[v_node] / sigma_sq;
            edge_idx++;
        }
    }

    *decoder_iteration = 0;
    double correctionValue = 0.75;
    bool isAllZero = true;

    // --- 解碼主迴圈 ---
    while (*decoder_iteration < decoder_max_iteration)
    {
        for (int i = 0; i < N; i++) ReturnTotal[i] = 0.0;

        /// --- STEP 1: CHECK NODE UPDATE (全面改用線性遞增指標) ---
        edge_idx = 0; // 每一輪疊代開始，重新從第 0 條邊出發
        for (int i = 0; i < M; i++)
        {
            int weight = H_rows[i].row_weight;

            int TotalNegativeCount = 0;
            minBeta first, second, third;
            first.minBetaValue = second.minBetaValue = third.minBetaValue = 1e100;

            // 第一次 Loop：直接依序讀取連續的記憶體區段
            for (int j = 0; j < weight; j++)
            {
                int k = edge_idx + j; // 計算這條邊在全域陣列中的絕對位置
                int v_node = H_row_places_flat[k];
                double v_message = Q_v2c[k];

                if (v_message < 0) TotalNegativeCount++;

                double tempValue = fabs(v_message);
                if (tempValue < first.minBetaValue) {
                    third = second; second = first;
                    first.minBetaValue = tempValue; first.minBetaPosition = v_node;
                }
                else if (tempValue < second.minBetaValue) {
                    third = second;
                    second.minBetaValue = tempValue; second.minBetaPosition = v_node;
                }
                else if (tempValue < third.minBetaValue) {
                    third.minBetaValue = tempValue;
                }
            }

            // 第二次 Loop：加入修正項並發送
            for (int j = 0; j < weight; j++)
            {
                int k = edge_idx + j;
                int tempPosition = H_row_places_flat[k];
                double v_message = Q_v2c[k];

                int self_sign = (v_message < 0) ? -1 : 1;
                int alpha = (TotalNegativeCount % 2 == 0) ? 1 : -1;
                int exclusion_alpha = alpha * self_sign;

                double pureMinValues = 0.0;
                double s_correction = 0.0;

                if (tempPosition == first.minBetaPosition) {
                    s_correction = s_tilde(correctionValue, second.minBetaValue, third.minBetaValue);
                    pureMinValues = second.minBetaValue;
                }
                else if (tempPosition == second.minBetaPosition) {
                    s_correction = s_tilde(correctionValue, first.minBetaValue, third.minBetaValue);
                    pureMinValues = first.minBetaValue;
                }
                else {
                    s_correction = s_tilde(correctionValue, first.minBetaValue, second.minBetaValue);
                    pureMinValues = first.minBetaValue;
                }

                double new_R = exclusion_alpha * (pureMinValues + s_correction);
                R_c2v[k] = new_R;
                ReturnTotal[tempPosition] += new_R;
            }

            edge_idx += weight; // 💡 關鍵：處理完一個 Check Node，直接跳過該列的權重長度
        }

        /// --- STEP 2: VARIABLE NODE UPDATE & HARD DECISION ---
        for (int i = 0; i < N; i++)
        {
            double LLR_intrinsic = 2.0 * LLR_Current[i] / sigma_sq;
            LLR_FinalResult[i] = LLR_intrinsic + ReturnTotal[i];
            Ci[i] = (LLR_FinalResult[i] >= 0.0) ? 0 : 1;
        }

        // 優化 2：更新 Q_v2c 邊訊息時，同步改用線性累加指標 edge_idx
        edge_idx = 0;
        for (int i = 0; i < M; i++)
        {
            int weight = H_rows[i].row_weight;
            for (int j = 0; j < weight; j++)
            {
                int v_node = H_row_places_flat[edge_idx];
                Q_v2c[edge_idx] = LLR_FinalResult[v_node] - R_c2v[edge_idx];
                edge_idx++;
            }
        }

        /// --- STEP 3: PARITY CHECK (同步改用線性累加指標優化) ---
        isAllZero = true;
        edge_idx = 0;
        for (int i = 0; i < M; i++)
        {
            int decision = 0;
            int weight = H_rows[i].row_weight;
            for (int j = 0; j < weight; j++) {
                decision += Ci[H_row_places_flat[edge_idx++]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break;
            }
        }

        if (isAllZero) {
            break;
        }
        *decoder_iteration += 1;
    }

    /// --- 終點線記分板 ---
    long long truebit = 0;
    long long falsebit = 0;

    for (int i = 0; i < N; i++)
    {
        if (Ci[i] == 0) {
            truebit++;
        }
        else {
            falsebit++;
        }
    }

    MinsumC->truebits += truebit;
    MinsumC->falsebits += falsebit;
    if (isAllZero) {
        MinsumC->sucess_time += 1;
    }
    else {
        MinsumC->error_time += 1;
    }


    free(LLR_FinalResult); free(Ci); free(ReturnTotal); free(R_c2v); free(Q_v2c);

    return isAllZero;
}





// --- (NOT FINISHED)minsum decoder main function ---
// --- minsum decoder main function ---
bool Decode_MinSum(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output) 
{
    //Read_H_MatrixByAlist();
    //Printf_H_Matrix("Minsum");

    // 動態記憶體配置 (使用 calloc 初始化為 0)
    double* LLR_Channel = (double*)calloc(N, sizeof(double));
    double* LLR_Current = (double*)calloc(N, sizeof(double));
    int* Ci = (int*)calloc(N, sizeof(int));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    // 1. 初始化 LLR
    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
    }

    *decoder_iteration = 0;

    // 可選的縮放因子 (Normalized Min-Sum 通常設為 0.75 ~ 0.8，若要純 Min-Sum 則設為 1.0)
    // Min-Sum 適合硬體實作或追求速度的場景。如果有需要逼近 SPA 的準確率，可以調整程式碼中的 alpha 值 (通常設為 0.75 或 0.8)，這稱為 Normalized Min-Sum Algorithm (NMSA)。
    double alpha = 1.0;
    long long truebit = 0, falsebit = 0;

    while (*decoder_iteration < decoder_max_iteration) {
        truebit = 0, falsebit = 0;

        // 每次迭代開始前，必須清空 Check Node 傳給 Variable Node 的累積訊息
        memset(ReturnTotalExceptI, 0, N * sizeof(double));

        // 2. Check Node Update (校驗節點更新 - Min-Sum 邏輯)
        for (int i = 0; i < M; i++) {
            int TotalNegativeCount = 0;
            double min1 = DBL_MAX; // 最小值
            double min2 = DBL_MAX; // 次小值
            int min1_idx = -1;     // 發生最小值的欄位索引

            int offset = H_rows[i].offset;
            int row_weight = H_rows[i].row_weight;

            // 第一次掃描：找出這一個 Row 中的 min1, min2 以及總負號數
            for (int j = 0; j < row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];
                double val = LLR_Current[col_idx];

                if (val < 0) TotalNegativeCount++;

                double abs_val = fabs(val);
                if (abs_val < min1) {
                    min2 = min1;
                    min1 = abs_val;
                    min1_idx = col_idx;
                }
                else if (abs_val < min2) {
                    min2 = abs_val;
                }
            }

            // 第二次掃描：將訊息發送給對應的 Variable Node
            for (int j = 0; j < row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];

                // 決定傳遞訊息的符號
                int sign = ((LLR_Current[col_idx] < 0 ? TotalNegativeCount - 1 : TotalNegativeCount) % 2 == 0) ? 1 : -1;

                // 決定傳遞訊息的大小：如果是最小值發生的節點，傳遞次小值；否則傳遞最小值
                double magnitude = (col_idx == min1_idx) ? min2 : min1;

                // 將外在訊息累加至 ReturnTotalExceptI (可乘上 alpha 做 Normalized Min-Sum)
                ReturnTotalExceptI[col_idx] += sign * magnitude * alpha;
            }
        }

        bool isAllZero = true;

        // 3. Variable Node Update 與 Hard Decision
        for (int i = 0; i < N; i++) {
            double LLR_FinalResult = LLR_Channel[i] + ReturnTotalExceptI[i];
            Ci[i] = (LLR_FinalResult > 0) ? 0 : 1;

            if (Ci[i] == 0) truebit++;
            else falsebit++;

            LLR_Current[i] = LLR_FinalResult;
        }

        // 4. Syndrome Check (驗證所有奇偶檢查方程式是否滿足)
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break; // 只要有一個沒滿足，就可以提早跳出檢查
            }
        }

        // 判斷是否成功或達到最大迭代
        if (isAllZero == true) {
            Minsum->truebits += truebit;
            Minsum->falsebits += falsebit;
            Minsum->sucess_time += 1;

            free(LLR_Channel); free(LLR_Current); free(Ci); free(ReturnTotalExceptI);
            //FREE_H_MatrixByAlist();

            return true;
        }
        *decoder_iteration += 1;
    }
    // 防呆清理
    Minsum->truebits += truebit;
    Minsum->falsebits += falsebit;
    Minsum->error_time += 1;
    free(LLR_Channel); free(LLR_Current); free(Ci); free(ReturnTotalExceptI);
    //FREE_H_MatrixByAlist();

    return false;
}
bool Decode_MinSumVer(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output)
{
    //Read_H_MatrixByAlist();
    //Printf_H_Matrix("Minsum");

    // 動態記憶體配置 (使用 calloc 初始化為 0)
    double* LLR_Channel = (double*)calloc(N, sizeof(double));
    double* LLR_Current = (double*)calloc(N, sizeof(double));
    int* Ci = (int*)calloc(N, sizeof(int));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    // 1. 初始化 LLR
    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
    }

    *decoder_iteration = 0;

    // 可選的縮放因子 (Normalized Min-Sum 通常設為 0.75 ~ 0.8，若要純 Min-Sum 則設為 1.0)
    // Min-Sum 適合硬體實作或追求速度的場景。如果有需要逼近 SPA 的準確率，可以調整程式碼中的 alpha 值 (通常設為 0.75 或 0.8)，這稱為 Normalized Min-Sum Algorithm (NMSA)。
    double alpha = 1.0;
    long long truebit = 0, falsebit = 0;

    while (*decoder_iteration < decoder_max_iteration) {
        truebit = 0, falsebit = 0;

        // 每次迭代開始前，必須清空 Check Node 傳給 Variable Node 的累積訊息
        memset(ReturnTotalExceptI, 0, N * sizeof(double));

        // 2. Check Node Update (校驗節點更新 - Min-Sum 邏輯)
        for (int i = 0; i < M; i++) {
            int TotalNegativeCount = 0;
            double min1 = DBL_MAX; // 最小值
            double min2 = DBL_MAX; // 次小值
            int min1_idx = -1;     // 發生最小值的欄位索引

            int offset = H_rows[i].offset;
            int row_weight = H_rows[i].row_weight;

            // 第一次掃描：找出這一個 Row 中的 min1, min2 以及總負號數
            for (int j = 0; j < row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];
                double val = LLR_Current[col_idx];

                if (val < 0) TotalNegativeCount++;

                double abs_val = fabs(val);
                if (abs_val < min1) {
                    min2 = min1;
                    min1 = abs_val;
                    min1_idx = col_idx;
                }
                else if (abs_val < min2) {
                    min2 = abs_val;
                }
            }

            // 第二次掃描：將訊息發送給對應的 Variable Node
            for (int j = 0; j < row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];

                // 決定傳遞訊息的符號
                int sign = ((LLR_Current[col_idx] < 0 ? TotalNegativeCount - 1 : TotalNegativeCount) % 2 == 0) ? 1 : -1;

                // 決定傳遞訊息的大小：如果是最小值發生的節點，傳遞次小值；否則傳遞最小值
                double magnitude = (col_idx == min1_idx) ? min2 : min1;

                // 將外在訊息累加至 ReturnTotalExceptI (可乘上 alpha 做 Normalized Min-Sum)
                ReturnTotalExceptI[col_idx] += sign * magnitude * alpha;
            }
        }

        bool isAllZero = true;

        // 3. Variable Node Update 與 Hard Decision
        for (int i = 0; i < N; i++) {
            double LLR_FinalResult = LLR_Channel[i] + ReturnTotalExceptI[i];
            Ci[i] = (LLR_FinalResult > 0) ? 0 : 1;

            if (Ci[i] == 0) truebit++;
            else falsebit++;

            LLR_Current[i] = LLR_FinalResult;
        }

        // 4. Syndrome Check (驗證所有奇偶檢查方程式是否滿足)
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break; // 只要有一個沒滿足，就可以提早跳出檢查
            }
        }

        // 判斷是否成功或達到最大迭代
        if (isAllZero == true) {
            Minsum->truebits += truebit;
            Minsum->falsebits += falsebit;
            Minsum->sucess_time += 1;

            free(LLR_Channel); free(LLR_Current); free(Ci); free(ReturnTotalExceptI);
            //FREE_H_MatrixByAlist();

            return true;
        }
        *decoder_iteration += 1;
    }
    // 防呆清理
    Minsum->truebits += truebit;
    Minsum->falsebits += falsebit;
    Minsum->error_time += 1;
    free(LLR_Channel); free(LLR_Current); free(Ci); free(ReturnTotalExceptI);
    //FREE_H_MatrixByAlist();

    return false;
}


bool Decode_NormalizedMinSum(double* channel_sigma, int* decoder_iteration, int decoder_max_iteration, double* channel_output)
{
    //Read_H_MatrixByAlist();
    //Printf_H_Matrix("Minsum");

    // 動態記憶體配置 (使用 calloc 初始化為 0)
    double* LLR_Channel = (double*)calloc(N, sizeof(double));
    double* LLR_Current = (double*)calloc(N, sizeof(double));
    int* Ci = (int*)calloc(N, sizeof(int));
    double* ReturnTotalExceptI = (double*)calloc(N, sizeof(double));

    // 1. 初始化 LLR
    for (int i = 0; i < N; i++) {
        LLR_Channel[i] = 2.0 * channel_output[i] / ((*channel_sigma) * (*channel_sigma));
        LLR_Current[i] = LLR_Channel[i];
    }

    *decoder_iteration = 0;

    // 可選的縮放因子 (Normalized Min-Sum 通常設為 0.75 ~ 0.8，若要純 Min-Sum 則設為 1.0)
    // Min-Sum 適合硬體實作或追求速度的場景。如果有需要逼近 SPA 的準確率，可以調整程式碼中的 alpha 值 (通常設為 0.75 或 0.8)，這稱為 Normalized Min-Sum Algorithm (NMSA)。
    double alpha = 1.0;
    long long truebit = 0, falsebit = 0;

    while (*decoder_iteration < decoder_max_iteration) {
        truebit = 0, falsebit = 0;

        // 每次迭代開始前，必須清空 Check Node 傳給 Variable Node 的累積訊息
        memset(ReturnTotalExceptI, 0, N * sizeof(double));

        // 2. Check Node Update (校驗節點更新 - Min-Sum 邏輯)
        for (int i = 0; i < M; i++) {
            int TotalNegativeCount = 0;
            double min1 = DBL_MAX; // 最小值
            double min2 = DBL_MAX; // 次小值
            int min1_idx = -1;     // 發生最小值的欄位索引

            int offset = H_rows[i].offset;
            int row_weight = H_rows[i].row_weight;

            // 第一次掃描：找出這一個 Row 中的 min1, min2 以及總負號數
            for (int j = 0; j < row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];
                double val = LLR_Current[col_idx];

                if (val < 0) TotalNegativeCount++;

                double abs_val = fabs(val);
                if (abs_val < min1) {
                    min2 = min1;
                    min1 = abs_val;
                    min1_idx = col_idx;
                }
                else if (abs_val < min2) {
                    min2 = abs_val;
                }
            }

            // 第二次掃描：將訊息發送給對應的 Variable Node
            for (int j = 0; j < row_weight; j++) {
                int col_idx = H_row_places_flat[offset + j];

                // 決定傳遞訊息的符號
                int sign = ((LLR_Current[col_idx] < 0 ? TotalNegativeCount - 1 : TotalNegativeCount) % 2 == 0) ? 1 : -1;

                // 決定傳遞訊息的大小：如果是最小值發生的節點，傳遞次小值；否則傳遞最小值
                double magnitude = (col_idx == min1_idx) ? min2 : min1;

                // 將外在訊息累加至 ReturnTotalExceptI (可乘上 alpha 做 Normalized Min-Sum)
                ReturnTotalExceptI[col_idx] += sign * magnitude * alpha;
            }
        }

        bool isAllZero = true;

        // 3. Variable Node Update 與 Hard Decision
        for (int i = 0; i < N; i++) {
            double LLR_FinalResult = LLR_Channel[i] + ReturnTotalExceptI[i];
            Ci[i] = (LLR_FinalResult > 0) ? 0 : 1;

            if (Ci[i] == 0) truebit++;
            else falsebit++;

            LLR_Current[i] = LLR_FinalResult;
        }

        // 4. Syndrome Check (驗證所有奇偶檢查方程式是否滿足)
        for (int i = 0; i < M; i++) {
            int decision = 0;
            int offset = H_rows[i].offset;
            for (int j = 0; j < H_rows[i].row_weight; j++) {
                decision += Ci[H_row_places_flat[offset + j]];
            }
            if (decision % 2 != 0) {
                isAllZero = false;
                break; // 只要有一個沒滿足，就可以提早跳出檢查
            }
        }

        // 判斷是否成功或達到最大迭代
        if (isAllZero == true) {
            Minsum->truebits += truebit;
            Minsum->falsebits += falsebit;
            Minsum->sucess_time += 1;

            free(LLR_Channel); free(LLR_Current); free(Ci); free(ReturnTotalExceptI);
            //FREE_H_MatrixByAlist();

            return true;
        }
        *decoder_iteration += 1;
    }
    // 防呆清理
    Minsum->truebits += truebit;
    Minsum->falsebits += falsebit;
    Minsum->error_time += 1;
    free(LLR_Channel); free(LLR_Current); free(Ci); free(ReturnTotalExceptI);
    //FREE_H_MatrixByAlist();

    return false;
}
