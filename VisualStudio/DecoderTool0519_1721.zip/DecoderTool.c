#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#include <string.h>

#include "DecoderTool.h"


int N = -1, K = -1, M = -1;
RowInfo* H_rows = NULL;
ColInfo* H_cols = NULL;

int* H_row_places_flat = NULL;
int* H_col_places_flat = NULL;

Decoder* SPA = NULL;
Decoder* Minsum = NULL;
Decoder* MinsumC = NULL;

// Read H Matrix

void Calculate_BERSER(Decoder* input_data)
{
    input_data->BER = (double)(input_data->falsebits) / (double)(input_data->truebits + input_data->falsebits);
    input_data->SER = (double)(input_data->error_time) / (double)(input_data->sucess_time + input_data->error_time);

}


// --- �ɮ�Ū�� (Alist) �אּ�@���s�x ---
void Read_H_MatrixByAlist(void) 
{
    FILE* fp = fopen(H_MATRIX_FILE, "r");

    if (!fp) {
        printf("[SYSTEM] Open file failed: %s\n", H_MATRIX_FILE);
        return;
    }

    int max_col_weight = 0, max_row_weight = 0;
    fscanf(fp, "%d %d", &N, &M);
    fscanf(fp, "%d %d", &max_col_weight, &max_row_weight);

    H_rows = (RowInfo*)malloc(M * sizeof(RowInfo));
    H_cols = (ColInfo*)malloc(N * sizeof(ColInfo));

    // ���t�s�򪺤@���Ŷ� (�j�p�� �`���*�̤j�v��)
    H_col_places_flat = (int*)malloc(N * max_col_weight * sizeof(int));
    H_row_places_flat = (int*)malloc(M * max_row_weight * sizeof(int));

    // Ū���v���íp�ⰾ���q
    for (int i = 0; i < N; i++) {
        fscanf(fp, "%d", &H_cols[i].column_weight);
        H_cols[i].offset = i * max_col_weight;
    }
    for (int i = 0; i < M; i++) {
        fscanf(fp, "%d", &H_rows[i].row_weight);
        H_rows[i].offset = i * max_row_weight;
    }

    int temp = 0;
    // Ū�� Column ��m��@���}�C
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < H_cols[i].column_weight; j++) {
            fscanf(fp, "%d", &temp);
            H_col_places_flat[H_cols[i].offset + j] = temp - 1;
        }
    }
    // Ū�� Row ��m��@���}�C
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < H_rows[i].row_weight; j++) {
            fscanf(fp, "%d", &temp);
            H_row_places_flat[H_rows[i].offset + j] = temp - 1;
        }
    }
    fclose(fp);
}
// --- release H matrix ---
void FREE_H_MatrixByAlist(void)
{
    free(H_rows);
    free(H_cols);
    free(H_col_places_flat);
    free(H_row_places_flat);
    return;
}





// Generate Gaussian Test Data
double generate_gaussian(double sigma) 
{
    double u1 = (double)rand() / RAND_MAX;
    double u2 = (double)rand() / RAND_MAX;
    if (u1 <= 0.0) u1 = 1e-9;
    double z0 = sqrt(-2.0 * log(u1)) * cos(2.0 * 3.14159265358979323846 * u2);
    return z0 * sigma;
}

void Generate_TestData(const int count, int N, int M, double EbN0_dB) 
{
    FILE* f_out = fopen(TEST_DATA_FILE, "w");
    if (!f_out) {
        perror("[System] Failed to open Gaussian TestData file\n");
        return;
    }

    double rate = (double)(N - M) / N;
    double snr = pow(10.0, EbN0_dB / 10.0);
    double sigma = sqrt(1.0 / (2.0 * rate * snr));

    srand((unsigned int)time(NULL));
    int* codeword = (int*)calloc(N, sizeof(int));

    for (int c = 0; c < count; c++) {
        fprintf(f_out, "\n%lf\n", sigma);
        for (int i = 0; i < N; i++) {
            double s = (codeword[i] == 0) ? 1.0 : -1.0;
            double y = s + generate_gaussian(sigma);
            fprintf(f_out, "%lf%s", y, (i == N - 1) ? "" : " ");
        }
        fprintf(f_out, "\n");
    }
    free(codeword);
    fclose(f_out);
    //printf("Successfully generated %d sets of data with Sigma: %lf\n", count, sigma);
}



// ���U�X���G�}�l�p��
void timer_start(CodeTimer* timer) {
    if (timer == NULL) return;

    // ���o���e���ѪR�׮ɶ� (TIME_UTC)
    timespec_get(&(timer->start_time), TIME_UTC);
    timer->is_running = true;
}

// ���U�X���G����p��
void timer_stop(CodeTimer* timer) {
    if (timer == NULL || !timer->is_running) return;

    timespec_get(&(timer->end_time), TIME_UTC);
    timer->is_running = false;
}

// --- �p�������ɶ��t�G��쬰 �@�� (ms) ---
double timer_get_ms(CodeTimer* timer) {
    if (timer == NULL) return 0.0;

    // �p�G�ϥΪ̧ѰO������A�N�H���e�ɶ��@���p����I�]���b����^
    struct timespec actual_end = timer->end_time;
    if (timer->is_running) {
        timespec_get(&actual_end, TIME_UTC);
    }

    double diff_sec = (double)(actual_end.tv_sec - timer->start_time.tv_sec);
    double diff_nsec = (double)(actual_end.tv_nsec - timer->start_time.tv_nsec);

    // �����⦨�@�� (*1000) + �`�����⦨�@�� (/1,000,000)
    return (diff_sec * 1000.0) + (diff_nsec / 1000000.0);
}

// �p�������ɶ��t�G��쬰 �� (sec)
double timer_get_sec(CodeTimer* timer) {
    // �����N�@�����H 1000 �Y�i�o�����
    return timer_get_ms(timer) / 1000.0;
}